package array_prblms;
import java.util.Arrays;
public class sorting_An_Array {

	public static void main(String[] args) {
int [] arr = {3,5,6,2,8,9,4};
	Arrays.sort(arr);
System.out.println(Arrays.toString(arr));
}
}